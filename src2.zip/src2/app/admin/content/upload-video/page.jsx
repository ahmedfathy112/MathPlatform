"use client";

import { useCallback, useEffect, useState } from "react";
import {
  Plus,
  Edit,
  Trash2,
  Video,
  X,
  Check,
  FolderKanban,
  BookOpen,
  Link as LinkIcon,
} from "lucide-react";
import { createClient } from "../../../utils/supabase/client";
import { useToast } from "../../../components/ui/ToastProvider";
import { Skeleton } from "../../../components/ui/Skeleton";

const emptyVideoForm = {
  id: null,
  title: "",
  description: "",
  video_url: "",
  package_id: "",
  subject_id: "",
  is_active: true,
};

function VideoFormModal({ initialValues, packagesList, onClose, onSaved }) {
  const { showToast } = useToast();
  const [form, setForm] = useState(initialValues);
  const [isSaving, setIsSaving] = useState(false);
  const isEditing = Boolean(initialValues.id);

  // المواد التابعة للباقة المختارة حالياً
  const selectedPackage = packagesList.find(
    (pkg) => pkg.id === form.package_id,
  );
  const availableSubjects = selectedPackage?.subjects ?? [];

  function updateField(field) {
    return (event) => {
      const value =
        field === "is_active" ? event.target.checked : event.target.value;
      setForm((prev) => {
        const updated = { ...prev, [field]: value };
        // إذا تم تغيير الباقة، نقوم بتفريغ اختيار المادة لتجنب عدم التوافق
        if (field === "package_id") {
          updated.subject_id = "";
        }
        return updated;
      });
    };
  }

  async function handleSubmit(event) {
    event.preventDefault();
    if (!form.title.trim() || !form.video_url.trim() || !form.subject_id) {
      showToast({
        type: "error",
        message: "يرجى إكمال الحقول الإجبارية واختيار الباقة والمادة.",
      });
      return;
    }

    setIsSaving(true);
    const supabase = createClient();
    const {
      data: { user },
    } = await supabase.auth.getUser();

    const payload = {
      title: form.title.trim(),
      description: form.description.trim() || null,
      video_url: form.video_url.trim(),
      subject_id: form.subject_id,
      is_active: form.is_active,
      created_by: process.env.NEXT_PUBLIC_SUPABASE_TEACHER,
    };

    const { error } = isEditing
      ? await supabase.from("videos").update(payload).eq("id", form.id)
      : await supabase.from("videos").insert(payload);

    setIsSaving(false);

    if (error) {
      showToast({
        type: "error",
        message: `تعذر حفظ الفيديو: ${error.message}`,
      });
      return;
    }

    showToast({
      type: "success",
      message: isEditing
        ? "تم تحديث الفيديو بنجاح."
        : "تم إضافة الفيديو بنجاح.",
    });
    onSaved();
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4 overflow-y-auto">
      <div className="w-full max-w-xl rounded-3xl bg-white p-6 shadow-xl dark:bg-slate-800 my-8">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold text-slate-900 dark:text-white">
            {isEditing ? "تعديل الفيديو" : "إضافة فيديو جديد"}
          </h2>
          <button
            onClick={onClose}
            className="rounded-lg p-1 text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700"
          >
            <X size={18} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-6 space-y-4">
          {/* اختيار الباقة الدراسية أولاً */}
          <div>
            <label className="text-sm font-medium text-slate-700 dark:text-slate-200">
              اختر الباقة الدراسية
            </label>
            <div className="relative mt-2">
              <span className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none text-slate-400">
                <FolderKanban size={18} />
              </span>
              <select
                value={form.package_id}
                onChange={updateField("package_id")}
                className="w-full rounded-2xl border border-slate-200 bg-slate-50 pr-10 pl-4 py-3 text-sm outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-200 dark:border-slate-700 dark:bg-slate-900 dark:text-white"
              >
                <option value="">-- اختر الباقة --</option>
                {packagesList.map((pkg) => (
                  <option key={pkg.id} value={pkg.id}>
                    {pkg.name} ({pkg.price_egp} ج.م)
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* اختيار المادة التابعة للباقة */}
          <div>
            <label className="text-sm font-medium text-slate-700 dark:text-slate-200">
              اختر المادة
            </label>
            <div className="relative mt-2">
              <span className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none text-slate-400">
                <BookOpen size={18} />
              </span>
              <select
                value={form.subject_id}
                onChange={updateField("subject_id")}
                disabled={!form.package_id || availableSubjects.length === 0}
                className="w-full rounded-2xl border border-slate-200 bg-slate-50 pr-10 pl-4 py-3 text-sm outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-200 disabled:opacity-50 dark:border-slate-700 dark:bg-slate-900 dark:text-white"
              >
                <option value="">-- اختر المادة --</option>
                {availableSubjects.map((subject) => (
                  <option key={subject.id} value={subject.id}>
                    {subject.name}
                  </option>
                ))}
              </select>
            </div>
            {!form.package_id && (
              <p className="mt-1 text-xs text-slate-500">
                يرجى اختيار الباقة أولاً لتظهر المواد المتاحة بداخلها.
              </p>
            )}
          </div>

          <div>
            <label className="text-sm font-medium text-slate-700 dark:text-slate-200">
              عنوان الفيديو
            </label>
            <input
              value={form.title}
              onChange={updateField("title")}
              className="mt-2 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-200 dark:border-slate-700 dark:bg-slate-900 dark:text-white"
              placeholder="مثال: المحاضرة الأولى - مقدمة الباب الأول"
            />
          </div>

          <div>
            <label className="text-sm font-medium text-slate-700 dark:text-slate-200">
              رابط الفيديو (URL)
            </label>
            <div className="relative mt-2">
              <span className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none text-slate-400">
                <LinkIcon size={18} />
              </span>
              <input
                value={form.video_url}
                onChange={updateField("video_url")}
                className="w-full rounded-2xl border border-slate-200 bg-slate-50 pr-10 pl-4 py-3 text-sm outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-200 dark:border-slate-700 dark:bg-slate-900 dark:text-white"
                placeholder="https://www.youtube.com/watch?v=..."
              />
            </div>
          </div>

          <div>
            <label className="text-sm font-medium text-slate-700 dark:text-slate-200">
              وصف الفيديو (اختياري)
            </label>
            <textarea
              value={form.description}
              onChange={updateField("description")}
              rows={3}
              className="mt-2 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-200 dark:border-slate-700 dark:bg-slate-900 dark:text-white"
            />
          </div>

          <label className="flex items-center gap-2 text-sm font-medium text-slate-700 dark:text-slate-200">
            <input
              type="checkbox"
              checked={form.is_active}
              onChange={updateField("is_active")}
              className="h-4 w-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
            />
            فيديو نشط (يظهر للطلاب المشتركين)
          </label>

          <button
            type="submit"
            disabled={isSaving}
            className="inline-flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-600 px-6 py-3 text-sm font-semibold text-white shadow-lg transition hover:shadow-xl disabled:opacity-60"
          >
            <Check size={18} />
            {isSaving ? "جارٍ الحفظ..." : "حفظ الفيديو"}
          </button>
        </form>
      </div>
    </div>
  );
}

export default function VideosManagementPage() {
  const { showToast } = useToast();
  const [videos, setVideos] = useState([]);
  const [packages, setPackages] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [videoModal, setVideoModal] = useState(null);

  const loadData = useCallback(async () => {
    setIsLoading(true);
    const supabase = createClient();

    // جلب الباقات مع موادها، والفيديوهات دفعة واحدة
    const [
      { data: pkgData, error: pkgError },
      { data: vidData, error: vidError },
    ] = await Promise.all([
      supabase
        .from("packages")
        .select("*, subjects(*)")
        .order("created_at", { ascending: false }),
      supabase
        .from("videos")
        .select("*, subjects(name, package_id, packages(name))")
        .order("created_at", { ascending: false }),
    ]);

    if (pkgError || vidError) {
      showToast({ type: "error", message: "تعذر تحميل بيانات الفيديوهات." });
      setIsLoading(false);
      return;
    }

    setPackages(pkgData ?? []);
    setVideos(vidData ?? []);
    setIsLoading(false);
  }, [showToast]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  async function handleDelete(video) {
    if (!window.confirm(`هل أنت متأكد من حذف فيديو "${video.title}"؟`)) return;

    const supabase = createClient();
    const { error } = await supabase.from("videos").delete().eq("id", video.id);

    if (error) {
      showToast({ type: "error", message: "تعذر حذف الفيديو." });
      return;
    }

    setVideos((prev) => prev.filter((v) => v.id !== video.id));
    showToast({ type: "success", message: "تم حذف الفيديو بنجاح." });
  }

  // عند فتح نموذج التعديل، نقوم بتجهيز package_id الخاص بالمادة لتظهر بشكل صحيح في الـ Modal
  function handleOpenEditModal(video) {
    const packageId = video.subjects?.package_id || "";
    setVideoModal({
      ...video,
      package_id: packageId,
    });
  }

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 dark:text-white">
            إدارة الفيديوهات
          </h1>
          <p className="mt-1 text-slate-600 dark:text-slate-400">
            رفع وتنظيم المحاضرات المرئية داخل المواد والباقات الدراسية.
          </p>
        </div>
        <button
          onClick={() => setVideoModal(emptyVideoForm)}
          className="inline-flex items-center gap-2 rounded-lg bg-gradient-to-r from-blue-600 to-indigo-600 px-6 py-2.5 font-medium text-white shadow-lg transition-all hover:shadow-xl hover:scale-105"
        >
          <Plus size={20} />
          إضافة فيديو جديد
        </button>
      </div>

      {isLoading ? (
        <div className="grid gap-6 grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 3 }).map((_, i) => (
            <Skeleton key={i} className="h-48 w-full rounded-2xl" />
          ))}
        </div>
      ) : videos.length === 0 ? (
        <div className="rounded-xl border border-slate-200 bg-white p-12 text-center shadow-sm dark:border-slate-700 dark:bg-slate-800">
          يوجد مادة فارغة أو لم تقم برفع أي فيديوهات حتى الآن.
        </div>
      ) : (
        <div className="grid gap-6 grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
          {videos.map((video) => (
            <div
              key={video.id}
              className="flex flex-col justify-between rounded-2xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-700 dark:bg-slate-800"
            >
              <div>
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <div className="rounded-lg bg-blue-50 p-2.5 text-blue-600 dark:bg-blue-900/30 dark:text-blue-400">
                      <Video size={20} />
                    </div>
                    <h3 className="font-bold text-slate-900 dark:text-white line-clamp-1">
                      {video.title}
                    </h3>
                  </div>
                  <span
                    className={`rounded-full px-2.5 py-0.5 text-xs font-semibold ${video.is_active ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400" : "bg-slate-200 text-slate-600 dark:bg-slate-700 dark:text-slate-300"}`}
                  >
                    {video.is_active ? "نشط" : "مخفي"}
                  </span>
                </div>

                <div className="mt-4 space-y-1 text-xs text-slate-500 dark:text-slate-400">
                  <p>
                    <strong className="text-slate-700 dark:text-slate-300">
                      الباقة:
                    </strong>{" "}
                    {video.subjects?.packages?.name ?? "غير محدد"}
                  </p>
                  <p>
                    <strong className="text-slate-700 dark:text-slate-300">
                      المادة:
                    </strong>{" "}
                    {video.subjects?.name ?? "غير محدد"}
                  </p>
                </div>

                {video.description && (
                  <p className="mt-3 text-sm text-slate-600 dark:text-slate-400 line-clamp-2">
                    {video.description}
                  </p>
                )}
              </div>

              <div className="mt-6 flex items-center justify-between border-t border-slate-100 pt-4 dark:border-slate-700">
                <a
                  href={video.video_url}
                  target="_blank"
                  rel="noreferrer"
                  className="text-xs font-semibold text-blue-600 hover:underline dark:text-blue-400"
                >
                  مشاهدة الرابط
                </a>
                <div className="flex gap-2">
                  <button
                    onClick={() => handleOpenEditModal(video)}
                    className="p-1.5 text-slate-400 hover:text-blue-600 dark:hover:text-blue-400"
                  >
                    <Edit size={16} />
                  </button>
                  <button
                    onClick={() => handleDelete(video)}
                    className="p-1.5 text-slate-400 hover:text-red-600 dark:hover:text-red-400"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {videoModal && (
        <VideoFormModal
          initialValues={videoModal}
          packagesList={packages}
          onClose={() => setVideoModal(null)}
          onSaved={() => {
            setVideoModal(null);
            loadData();
          }}
        />
      )}
    </div>
  );
}
