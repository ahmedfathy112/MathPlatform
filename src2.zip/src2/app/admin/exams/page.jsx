"use client";

import { useCallback, useEffect, useState } from "react";
import {
  Plus,
  Edit,
  Trash2,
  FileText,
  Users,
  Award,
  X,
  Check,
  Eye,
} from "lucide-react";
import Link from "next/link";
import { createClient } from "../../utils/supabase/client";
import { useToast } from "../../components/ui/ToastProvider";
import { Skeleton } from "../../components/ui/Skeleton";

// نافذة منبثقة لعرض نتائج الطلاب في امتحان معين
function ExamAttemptsModal({ exam, onClose }) {
  const { showToast } = useToast();
  const [attempts, setAttempts] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  const loadAttempts = useCallback(async () => {
    setIsLoading(true);
    const supabase = createClient();

    const { data, error } = await supabase
      .from("exam_attempts")
      .select("*, profiles(full_name, phone)")
      .eq("exam_id", exam.id)
      .order("score", { ascending: false });

    if (error) {
      showToast({ type: "error", message: "تعذر تحميل نتائج الطلاب." });
      setIsLoading(false);
      return;
    }

    setAttempts(data ?? []);
    setIsLoading(false);
  }, [exam.id, showToast]);

  useEffect(() => {
    loadAttempts();
  }, [loadAttempts]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4 overflow-y-auto">
      <div className="w-full max-w-3xl rounded-3xl bg-white p-6 shadow-xl dark:bg-slate-800 my-8">
        <div className="flex items-center justify-between border-b border-slate-200 pb-4 dark:border-slate-700">
          <div>
            <h2 className="text-xl font-bold text-slate-900 dark:text-white">
              نتائج امتحان: {exam.title}
            </h2>
            <p className="text-sm text-slate-500">
              المادة: {exam.subjects?.name} ({exam.subjects?.packages?.name})
            </p>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-1 text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700"
          >
            <X size={20} />
          </button>
        </div>

        <div className="mt-6 max-h-[60vh] overflow-y-auto">
          {isLoading ? (
            <div className="space-y-3">
              {Array.from({ length: 3 }).map((_, i) => (
                <Skeleton key={i} className="h-16 w-full rounded-xl" />
              ))}
            </div>
          ) : attempts.length === 0 ? (
            <div className="py-12 text-center text-slate-500 dark:text-slate-400">
              لم يقم أي طالب بأداء هذا الامتحان حتى الآن.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-right text-sm text-slate-600 dark:text-slate-300">
                <thead className="bg-slate-50 text-xs uppercase text-slate-700 dark:bg-slate-900 dark:text-slate-400">
                  <tr>
                    <th className="px-4 py-3">اسم الطالب</th>
                    <th className="px-4 py-3">رقم الهاتف</th>
                    <th className="px-4 py-3">الدرجة الحاصل عليها</th>
                    <th className="px-4 py-3">وقت التسليم</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 dark:divide-slate-700">
                  {attempts.map((att) => (
                    <tr
                      key={att.id}
                      className="hover:bg-slate-50 dark:hover:bg-slate-700/50"
                    >
                      <td className="px-4 py-3 font-medium text-slate-900 dark:text-white">
                        {att.profiles?.full_name ?? "طالب غير معروف"}
                      </td>
                      <td className="px-4 py-3">
                        {att.profiles?.phone ?? "غير محدد"}
                      </td>
                      <td className="px-4 py-3 font-bold text-blue-600 dark:text-blue-400">
                        {att.score} / {exam.total_marks ?? "-"}
                      </td>
                      <td className="px-4 py-3 text-xs text-slate-400">
                        {new Date(att.created_at).toLocaleString("ar-EG")}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default function ExamsManagementPage() {
  const { showToast } = useToast();
  const [exams, setExams] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedExamForAttempts, setSelectedExamForAttempts] = useState(null);

  const loadExams = useCallback(async () => {
    setIsLoading(true);
    const supabase = createClient();

    const { data, error } = await supabase
      .from("exams")
      .select("*, subjects(name, package_id, packages(name))")
      .order("created_at", { ascending: false });

    if (error) {
      showToast({ type: "error", message: "تعذر تحميل الامتحانات." });
      setIsLoading(false);
      return;
    }

    setExams(data ?? []);
    setIsLoading(false);
  }, [showToast]);

  useEffect(() => {
    loadExams();
  }, [loadExams]);

  async function handleDelete(exam) {
    if (!window.confirm(`هل أنت متأكد من حذف امتحان "${exam.title}"؟`)) return;

    const supabase = createClient();
    const { error } = await supabase.from("exams").delete().eq("id", exam.id);

    if (error) {
      showToast({ type: "error", message: "تعذر حذف الامتحان." });
      return;
    }

    setExams((prev) => prev.filter((e) => e.id !== exam.id));
    showToast({ type: "success", message: "تم حذف الامتحان بنجاح." });
  }

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 dark:text-white">
            إدارة الامتحانات
          </h1>
          <p className="mt-1 text-slate-600 dark:text-slate-400">
            إنشاء ومتابعة الاختبارات واستعراض نتائج الطلاب.
          </p>
        </div>
        <Link
          href="/admin/exams/create"
          className="inline-flex items-center gap-2 rounded-lg bg-gradient-to-r from-blue-600 to-indigo-600 px-6 py-2.5 font-medium text-white shadow-lg transition-all hover:shadow-xl hover:scale-105"
        >
          <Plus size={20} />
          إنشاء امتحان جديد
        </Link>
      </div>

      {isLoading ? (
        <div className="grid gap-6 grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 3 }).map((_, i) => (
            <Skeleton key={i} className="h-56 w-full rounded-2xl" />
          ))}
        </div>
      ) : exams.length === 0 ? (
        <div className="rounded-xl border border-slate-200 bg-white p-12 text-center shadow-sm dark:border-slate-700 dark:bg-slate-800">
          <FileText size={48} className="mx-auto mb-4 text-slate-400" />
          <p className="text-lg font-medium text-slate-900 dark:text-white">
            لا توجد امتحانات مضافة بعد
          </p>
          <p className="mt-1 text-slate-600 dark:text-slate-400">
            ابدأ بإنشاء أول امتحان لتقييم الطلاب.
          </p>
        </div>
      ) : (
        <div className="grid gap-6 grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
          {exams.map((exam) => (
            <div
              key={exam.id}
              className="flex flex-col justify-between rounded-2xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-700 dark:bg-slate-800"
            >
              <div>
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <div className="rounded-lg bg-indigo-50 p-2.5 text-indigo-600 dark:bg-indigo-900/30 dark:text-indigo-400">
                      <FileText size={20} />
                    </div>
                    <h3 className="font-bold text-slate-900 dark:text-white line-clamp-1">
                      {exam.title}
                    </h3>
                  </div>
                  <span
                    className={`rounded-full px-2.5 py-0.5 text-xs font-semibold ${exam.is_active ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400" : "bg-slate-200 text-slate-600 dark:bg-slate-700 dark:text-slate-300"}`}
                  >
                    {exam.is_active ? "متاح" : "مغلق"}
                  </span>
                </div>

                <div className="mt-4 space-y-1 text-xs text-slate-500 dark:text-slate-400">
                  <p>
                    <strong className="text-slate-700 dark:text-slate-300">
                      الباقة:
                    </strong>{" "}
                    {exam.subjects?.packages?.name ?? "غير محدد"}
                  </p>
                  <p>
                    <strong className="text-slate-700 dark:text-slate-300">
                      المادة:
                    </strong>{" "}
                    {exam.subjects?.name ?? "غير محدد"}
                  </p>
                  <p>
                    <strong className="text-slate-700 dark:text-slate-300">
                      الدرجة الكلية:
                    </strong>{" "}
                    {exam.total_marks ?? "غير محدد"}
                  </p>
                </div>

                {exam.description && (
                  <p className="mt-3 text-sm text-slate-600 dark:text-slate-400 line-clamp-2">
                    {exam.description}
                  </p>
                )}
              </div>

              <div className="mt-6 flex items-center justify-between border-t border-slate-100 pt-4 dark:border-slate-700">
                <button
                  onClick={() => setSelectedExamForAttempts(exam)}
                  className="inline-flex items-center gap-1.5 text-xs font-semibold text-blue-600 hover:underline dark:text-blue-400"
                >
                  <Eye size={16} />
                  استعراض النتائج
                </button>
                <div className="flex gap-2">
                  <button
                    onClick={() => handleDelete(exam)}
                    className="p-1.5 text-slate-400 hover:text-red-600 dark:hover:text-red-400"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {selectedExamForAttempts && (
        <ExamAttemptsModal
          exam={selectedExamForAttempts}
          onClose={() => setSelectedExamForAttempts(null)}
        />
      )}
    </div>
  );
}
