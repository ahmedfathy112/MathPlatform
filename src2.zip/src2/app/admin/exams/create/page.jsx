"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import {
  FolderKanban,
  BookOpen,
  Check,
  ArrowRight,
  Plus,
  Trash2,
  Upload,
  Image as ImageIcon,
} from "lucide-react";
import Link from "next/link";
import { createClient } from "../../../utils/supabase/client";
import { useToast } from "../../../components/ui/ToastProvider";

export default function CreateExamPage() {
  const router = useRouter();
  const { showToast } = useToast();

  const [packages, setPackages] = useState([]);
  const [selectedPackageId, setSelectedPackageId] = useState("");
  const [isSaving, setIsSaving] = useState(false);

  const [form, setForm] = useState({
    title: "",
    description: "",
    subject_id: "",
    start_time: "",
    end_time: "",
    duration_minutes: 60,
  });

  // قائمة الأسئلة مع دعم ملفات الصور المحلية
  const [questions, setQuestions] = useState([
    {
      imageFile: null,
      imagePreview: "",
      options: { A: "", B: "", C: "", D: "" },
      correct_option: "A",
    },
  ]);

  useEffect(() => {
    async function fetchPackages() {
      const supabase = createClient();
      const { data, error } = await supabase
        .from("packages")
        .select("*, subjects(*)")
        .order("created_at", { ascending: false });

      if (error) {
        showToast({ type: "error", message: "تعذر تحميل الباقات الدراسية." });
        return;
      }
      setPackages(data ?? []);
    }
    fetchPackages();
  }, [showToast]);

  const selectedPkg = packages.find((p) => p.id === selectedPackageId);
  const availableSubjects = selectedPkg?.subjects ?? [];

  function updateField(field, value) {
    setForm((prev) => ({ ...prev, [field]: value }));
  }

  // إدارة الأسئلة
  function handleAddQuestion() {
    setQuestions((prev) => [
      ...prev,
      {
        imageFile: null,
        imagePreview: "",
        options: { A: "", B: "", C: "", D: "" },
        correct_option: "A",
      },
    ]);
  }

  function handleRemoveQuestion(index) {
    if (questions.length === 1) {
      showToast({
        type: "error",
        message: "يجب أن يحتوي الامتحان على سؤال واحد على الأقل.",
      });
      return;
    }
    setQuestions((prev) => prev.filter((_, i) => i !== index));
  }

  function handleQuestionChange(index, field, value) {
    setQuestions((prev) => {
      const updated = [...prev];
      updated[index][field] = value;
      return updated;
    });
  }

  function handleOptionChange(qIndex, optKey, value) {
    setQuestions((prev) => {
      const updated = [...prev];
      updated[qIndex].options[optKey] = value;
      return updated;
    });
  }

  // التعامل مع اختيار صورة السؤال من الجهاز
  function handleImageFileChange(index, e) {
    const file = e.target.files[0];
    if (!file) return;

    const previewUrl = URL.createObjectURL(file);
    setQuestions((prev) => {
      const updated = [...prev];
      updated[index].imageFile = file;
      updated[index].imagePreview = previewUrl;
      return updated;
    });
  }

  async function handleSubmit(e) {
    e.preventDefault();
    if (
      !form.title.trim() ||
      !form.subject_id ||
      !selectedPackageId ||
      !form.start_time ||
      !form.end_time
    ) {
      showToast({
        type: "error",
        message: "يرجى إكمال الحقول الأساسية للامتحان ومواعيد البدء والانتهاء.",
      });
      return;
    }

    if (new Date(form.end_time) <= new Date(form.start_time)) {
      showToast({
        type: "error",
        message: "وقت الانتهاء يجب أن يكون بعد وقت البدء.",
      });
      return;
    }

    // التحقق من صحة الأسئلة والصور
    for (let i = 0; i < questions.length; i++) {
      const q = questions[i];
      if (!q.imageFile) {
        showToast({
          type: "error",
          message: `يرجى إرفاق صورة للسؤال رقم ${i + 1}.`,
        });
        return;
      }
      if (!q.options.A || !q.options.B || !q.options.C || !q.options.D) {
        showToast({
          type: "error",
          message: `يرجى إكمال كافة الاختيارات (A, B, C, D) للسؤال رقم ${i + 1}.`,
        });
        return;
      }
    }

    setIsSaving(true);
    const supabase = createClient();
    const {
      data: { user },
      error: userError,
    } = await supabase.auth.getUser();

    if (userError || !user) {
      showToast({
        type: "error",
        message: "جلسة المستخدم انتهت، يرجى إعادة تسجيل الدخول.",
      });
      setIsSaving(false);
      return;
    }

    const examPayload = {
      title: form.title.trim(),
      description: form.description.trim() || null,
      subject_id: form.subject_id,
      start_time: new Date(form.start_time).toISOString(),
      end_time: new Date(form.end_time).toISOString(),
      duration_minutes: Number(form.duration_minutes) || 1,
      created_by: process.env.NEXT_PUBLIC_SUPABASE_TEACHER,
    };

    const { data: insertedExam, error: examError } = await supabase
      .from("exams")
      .insert(examPayload)
      .select()
      .single();

    if (examError || !insertedExam) {
      showToast({
        type: "error",
        message: `تعذر إنشاء الامتحان: ${examError?.message}`,
      });
      setIsSaving(false);
      return;
    }

    // 2. رفع صور الأسئلة إلى bucket (question-images) وتجهيز بيانات الأسئلة
    const questionsPayload = [];
    for (let i = 0; i < questions.length; i++) {
      const q = questions[i];
      const fileExt = q.imageFile.name.split(".").pop();
      const fileName = `${insertedExam.id}_${Date.now()}_${i}.${fileExt}`;
      const filePath = `${fileName}`;

      // رفع الصورة للـ Bucket
      const { error: uploadError } = await supabase.storage
        .from("question-images")
        .upload(filePath, q.imageFile);

      if (uploadError) {
        showToast({
          type: "error",
          message: `تعذر رفع صورة السؤال رقم ${i + 1}: ${uploadError.message}`,
        });
        setIsSaving(false);
        return;
      }

      // جلب الرابط العام (Public URL) للصورة المرفوعة
      const { data: publicUrlData } = supabase.storage
        .from("question-images")
        .getPublicUrl(filePath);

      questionsPayload.push({
        exam_id: insertedExam.id,
        image_url: publicUrlData.publicUrl,
        options: q.options,
        correct_option: q.correct_option,
        order_index: i,
      });
    }

    // 3. إدخال الأسئلة في جدول questions
    const { error: questionsError } = await supabase
      .from("questions")
      .insert(questionsPayload);

    setIsSaving(false);

    if (questionsError) {
      showToast({
        type: "error",
        message: `تم إنشاء الامتحان ولكن تعذر حفظ الأسئلة: ${questionsError.message}`,
      });
      return;
    }

    showToast({
      type: "success",
      message: "تم إنشاء الامتحان والأسئلة ورفع الصور بنجاح.",
    });
    router.push("/admin/exams");
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-12">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">
            إنشاء امتحان جديد مع الأسئلة
          </h1>
          <p className="text-sm text-slate-500">
            اختر الباقة والمادة، حدد مواعيد الامتحان، وارفَع صور الأسئلة من
            جهازك.
          </p>
        </div>
        <Link
          href="/dashboard/exams"
          className="inline-flex items-center gap-1 text-sm font-medium text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white"
        >
          <ArrowRight size={16} />
          العودة للرئيسية
        </Link>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* التفاصيل الأساسية للامتحان */}
        <div className="rounded-3xl border border-slate-200 bg-white p-8 shadow-sm dark:border-slate-700 dark:bg-slate-800 space-y-6">
          <h2 className="text-lg font-bold text-slate-900 dark:text-white border-b border-slate-100 pb-3 dark:border-slate-700">
            1. التفاصيل الأساسية للامتحان
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium text-slate-700 dark:text-slate-200">
                الباقة الدراسية
              </label>
              <div className="relative mt-2">
                <span className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none text-slate-400">
                  <FolderKanban size={18} />
                </span>
                <select
                  value={selectedPackageId}
                  onChange={(e) => {
                    setSelectedPackageId(e.target.value);
                    updateField("subject_id", "");
                  }}
                  className="w-full rounded-2xl border border-slate-200 bg-slate-50 pr-10 pl-4 py-3 text-sm outline-none focus:border-blue-500 dark:border-slate-700 dark:bg-slate-900 dark:text-white"
                >
                  <option value="">-- اختر الباقة --</option>
                  {packages.map((pkg) => (
                    <option key={pkg.id} value={pkg.id}>
                      {pkg.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="text-sm font-medium text-slate-700 dark:text-slate-200">
                المادة الدراسية
              </label>
              <div className="relative mt-2">
                <span className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none text-slate-400">
                  <BookOpen size={18} />
                </span>
                <select
                  value={form.subject_id}
                  onChange={(e) => updateField("subject_id", e.target.value)}
                  disabled={
                    !selectedPackageId || availableSubjects.length === 0
                  }
                  className="w-full rounded-2xl border border-slate-200 bg-slate-50 pr-10 pl-4 py-3 text-sm outline-none focus:border-blue-500 disabled:opacity-50 dark:border-slate-700 dark:bg-slate-900 dark:text-white"
                >
                  <option value="">-- اختر المادة --</option>
                  {availableSubjects.map((sub) => (
                    <option key={sub.id} value={sub.id}>
                      {sub.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          <div>
            <label className="text-sm font-medium text-slate-700 dark:text-slate-200">
              عنوان الامتحان
            </label>
            <input
              value={form.title}
              onChange={(e) => updateField("title", e.target.value)}
              placeholder="مثال: امتحان الشهر الأول في الجبر"
              className="mt-2 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm outline-none focus:border-blue-500 dark:border-slate-700 dark:bg-slate-900 dark:text-white"
            />
          </div>

          <div>
            <label className="text-sm font-medium text-slate-700 dark:text-slate-200">
              وصف أو تعليمات الامتحان (اختياري)
            </label>
            <textarea
              value={form.description}
              onChange={(e) => updateField("description", e.target.value)}
              rows={2}
              className="mt-2 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm outline-none focus:border-blue-500 dark:border-slate-700 dark:bg-slate-900 dark:text-white"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="text-sm font-medium text-slate-700 dark:text-slate-200">
                وقت البدء
              </label>
              <input
                type="datetime-local"
                value={form.start_time}
                onChange={(e) => updateField("start_time", e.target.value)}
                className="mt-2 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm outline-none focus:border-blue-500 dark:border-slate-700 dark:bg-slate-900 dark:text-white"
              />
            </div>
            <div>
              <label className="text-sm font-medium text-slate-700 dark:text-slate-200">
                وقت الانتهاء
              </label>
              <input
                type="datetime-local"
                value={form.end_time}
                onChange={(e) => updateField("end_time", e.target.value)}
                className="mt-2 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm outline-none focus:border-blue-500 dark:border-slate-700 dark:bg-slate-900 dark:text-white"
              />
            </div>
            <div>
              <label className="text-sm font-medium text-slate-700 dark:text-slate-200">
                المدة (بالدقائق)
              </label>
              <input
                type="number"
                min="1"
                value={form.duration_minutes}
                onChange={(e) =>
                  updateField("duration_minutes", e.target.value)
                }
                className="mt-2 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm outline-none focus:border-blue-500 dark:border-slate-700 dark:bg-slate-900 dark:text-white"
              />
            </div>
          </div>
        </div>

        {/* قسم الأسئلة ورفع الصور والاختيارات */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-bold text-slate-900 dark:text-white">
              2. أسئلة الامتحان ({questions.length})
            </h2>
            <button
              type="button"
              onClick={handleAddQuestion}
              className="inline-flex items-center gap-1.5 rounded-xl bg-blue-50 px-4 py-2 text-xs font-semibold text-blue-600 hover:bg-blue-100 dark:bg-blue-900/30 dark:text-blue-400"
            >
              <Plus size={16} />
              إضافة سؤال جديد
            </button>
          </div>

          {questions.map((q, qIndex) => (
            <div
              key={qIndex}
              className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-700 dark:bg-slate-800 space-y-4 relative"
            >
              <div className="flex items-center justify-between border-b border-slate-100 pb-3 dark:border-slate-700">
                <span className="font-bold text-slate-800 dark:text-slate-200">
                  السؤال رقم {qIndex + 1}
                </span>
                {questions.length > 1 && (
                  <button
                    type="button"
                    onClick={() => handleRemoveQuestion(qIndex)}
                    className="p-1.5 text-red-500 hover:bg-red-50 rounded-lg dark:hover:bg-red-900/20"
                  >
                    <Trash2 size={18} />
                  </button>
                )}
              </div>

              {/* رفع صورة السؤال من الجهاز */}
              <div>
                <label className="text-xs font-medium text-slate-700 dark:text-slate-300">
                  صورة السؤال (من الجهاز)
                </label>
                <div className="mt-1 flex items-center gap-4">
                  <label className="flex cursor-pointer items-center gap-2 rounded-xl border border-dashed border-slate-300 bg-slate-50 px-4 py-3 text-sm font-medium text-slate-600 hover:bg-slate-100 dark:border-slate-600 dark:bg-slate-900 dark:text-slate-300">
                    <Upload size={18} />
                    <span>
                      {q.imageFile ? q.imageFile.name : "اختر صورة السؤال"}
                    </span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={(e) => handleImageFileChange(qIndex, e)}
                      className="hidden"
                    />
                  </label>
                  {q.imagePreview && (
                    <div className="relative h-12 w-12 overflow-hidden rounded-lg border border-slate-200">
                      <img
                        src={q.imagePreview}
                        alt="معاينة"
                        className="h-full w-full object-cover"
                      />
                    </div>
                  )}
                </div>
              </div>

              {/* الاختيارات الأربعة A, B, C, D */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {["A", "B", "C", "D"].map((optKey) => (
                  <div key={optKey}>
                    <label className="text-xs font-medium text-slate-600 dark:text-slate-400">
                      الخيار {optKey}
                    </label>
                    <input
                      value={q.options[optKey]}
                      onChange={(e) =>
                        handleOptionChange(qIndex, optKey, e.target.value)
                      }
                      placeholder={`نص الخيار ${optKey}`}
                      className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-sm outline-none focus:border-blue-500 dark:border-slate-700 dark:bg-slate-900 dark:text-white"
                    />
                  </div>
                ))}
              </div>

              {/* الإجابة الصحيحة */}
              <div>
                <label className="text-xs font-medium text-slate-700 dark:text-slate-300">
                  الإجابة الصحيحة
                </label>
                <select
                  value={q.correct_option}
                  onChange={(e) =>
                    handleQuestionChange(
                      qIndex,
                      "correct_option",
                      e.target.value,
                    )
                  }
                  className="mt-1 w-full sm:w-1/3 rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-sm outline-none focus:border-blue-500 dark:border-slate-700 dark:bg-slate-900 dark:text-white"
                >
                  <option value="A">الخيار A</option>
                  <option value="B">الخيار B</option>
                  <option value="C">الخيار C</option>
                  <option value="D">الخيار D</option>
                </select>
              </div>
            </div>
          ))}
        </div>

        <button
          type="submit"
          disabled={isSaving}
          className="inline-flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-600 px-6 py-3 text-sm font-semibold text-white shadow-lg transition hover:shadow-xl disabled:opacity-60"
        >
          <Check size={18} />
          {isSaving
            ? "جارٍ الرفع والحفظ..."
            : "حفظ الامتحان مع الأسئلة ورفع الصور"}
        </button>
      </form>
    </div>
  );
}
