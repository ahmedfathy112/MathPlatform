"use client";

import { useCallback, useEffect, useState } from "react";
import { Plus, Edit, Trash2, Users, X, Check, BookOpen } from "lucide-react";
import { createClient } from "../../utils/supabase/client";
import { useToast } from "../../components/ui/ToastProvider";
import { Skeleton } from "../../components/ui/Skeleton";
import { GRADE_LABELS } from "../../utils/supabase/adminHelpers";

const GRADE_OPTIONS = Object.entries(GRADE_LABELS);

// ==========================================
// 1. نماذج البيانات الافتراضية
// ==========================================
const emptyPackageForm = {
  id: null,
  name: "",
  grade_level: "secondary_1",
  description: "",
  price_egp: "",
  is_active: true,
};

const emptySubjectForm = {
  id: null,
  name: "",
  description: "",
  is_active: true,
  package_id: null, // سيتم تمريره
};

// ==========================================
// 2. نافذة إضافة/تعديل الباقة (Package)
// ==========================================
function PackageFormModal({ initialValues, onClose, onSaved }) {
  const { showToast } = useToast();
  const [form, setForm] = useState(initialValues);
  const [isSaving, setIsSaving] = useState(false);
  const isEditing = Boolean(initialValues.id);

  function updateField(field) {
    return (event) => {
      const value =
        field === "is_active" ? event.target.checked : event.target.value;
      setForm((prev) => ({ ...prev, [field]: value }));
    };
  }

  async function handleSubmit(event) {
    event.preventDefault();
    if (!form.name.trim()) {
      showToast({ type: "error", message: "يرجى إدخال اسم الباقة." });
      return;
    }

    setIsSaving(true);
    const supabase = createClient();

    // تأمين جلب معرف المعلم بأي طريقة تستخدمها (حسب نظامك)
    const teacherId = process.env.NEXT_PUBLIC_SUPABASE_TEACHER;

    const payload = {
      name: form.name.trim(),
      grade_level: form.grade_level,
      description: form.description.trim() || null,
      price_egp: form.price_egp ? Number(form.price_egp) : 0,
      is_active: form.is_active,
      created_by: teacherId,
    };

    const { error } = isEditing
      ? await supabase.from("packages").update(payload).eq("id", form.id)
      : await supabase.from("packages").insert(payload);

    setIsSaving(false);

    if (error) {
      showToast({ type: "error", message: "تعذر حفظ الباقة." });
      return;
    }

    showToast({
      type: "success",
      message: isEditing ? "تم تحديث الباقة." : "تم إنشاء الباقة بنجاح.",
    });
    onSaved();
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
      <div className="w-full max-w-lg rounded-3xl bg-white p-6 shadow-xl dark:bg-slate-800">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold text-slate-900 dark:text-white">
            {isEditing ? "تعديل الباقة" : "باقة دراسية جديدة"}
          </h2>
          <button
            onClick={onClose}
            className="rounded-lg p-1 text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700"
          >
            <X size={18} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-6 space-y-4">
          <div>
            <label className="text-sm font-medium text-slate-700 dark:text-slate-200">
              اسم الباقة
            </label>
            <input
              value={form.name}
              onChange={updateField("name")}
              className="mt-2 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-200 dark:border-slate-700 dark:bg-slate-900 dark:text-white"
              placeholder="مثال: الصف الثاني الثانوي - الترم الأول"
            />
          </div>

          <div>
            <label className="text-sm font-medium text-slate-700 dark:text-slate-200">
              الصف الدراسي
            </label>
            <select
              value={form.grade_level}
              onChange={updateField("grade_level")}
              className="mt-2 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-200 dark:border-slate-700 dark:bg-slate-900 dark:text-white"
            >
              {GRADE_OPTIONS.map(([value, label]) => (
                <option key={value} value={value}>
                  {label}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-sm font-medium text-slate-700 dark:text-slate-200">
              سعر الباقة (جنيه)
            </label>
            <input
              type="number"
              value={form.price_egp}
              onChange={updateField("price_egp")}
              className="mt-2 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-200 dark:border-slate-700 dark:bg-slate-900 dark:text-white"
              placeholder="مثال: 250"
            />
          </div>

          <div>
            <label className="text-sm font-medium text-slate-700 dark:text-slate-200">
              الوصف (اختياري)
            </label>
            <textarea
              value={form.description}
              onChange={updateField("description")}
              rows={3}
              className="mt-2 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-200 dark:border-slate-700 dark:bg-slate-900 dark:text-white"
            />
          </div>

          <label className="flex items-center gap-2 text-sm font-medium text-slate-700 dark:text-slate-200">
            <input
              type="checkbox"
              checked={form.is_active}
              onChange={updateField("is_active")}
              className="h-4 w-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
            />
            باقة نشطة (متاحة للشراء)
          </label>

          <button
            type="submit"
            disabled={isSaving}
            className="inline-flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-600 px-6 py-3 text-sm font-semibold text-white shadow-lg transition hover:shadow-xl disabled:opacity-60"
          >
            <Check size={18} />
            {isSaving ? "جارٍ الحفظ..." : "حفظ الباقة"}
          </button>
        </form>
      </div>
    </div>
  );
}

// ==========================================
// 3. نافذة إضافة/تعديل المادة (Subject)
// ==========================================
function SubjectFormModal({ initialValues, packageData, onClose, onSaved }) {
  const { showToast } = useToast();
  const [form, setForm] = useState(initialValues);
  const [isSaving, setIsSaving] = useState(false);
  const isEditing = Boolean(initialValues.id);

  function updateField(field) {
    return (event) => {
      const value =
        field === "is_active" ? event.target.checked : event.target.value;
      setForm((prev) => ({ ...prev, [field]: value }));
    };
  }

  async function handleSubmit(event) {
    event.preventDefault();
    if (!form.name.trim()) {
      showToast({ type: "error", message: "يرجى إدخال اسم المادة." });
      return;
    }

    setIsSaving(true);
    const supabase = createClient();
    const teacherId = process.env.NEXT_PUBLIC_SUPABASE_TEACHER;

    const payload = {
      name: form.name.trim(),
      description: form.description.trim() || null,
      is_active: form.is_active,
      package_id: packageData.id,
      grade_level: packageData.grade_level, // المادة تورث الصف الدراسي من الباقة
      created_by: teacherId,
    };

    const { error } = isEditing
      ? await supabase.from("subjects").update(payload).eq("id", form.id)
      : await supabase.from("subjects").insert(payload);

    setIsSaving(false);

    if (error) {
      showToast({ type: "error", message: "تعذر حفظ المادة." });
      return;
    }

    showToast({
      type: "success",
      message: isEditing ? "تم تحديث المادة." : "تمت إضافة المادة للباقة.",
    });
    onSaved();
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
      <div className="w-full max-w-lg rounded-3xl bg-white p-6 shadow-xl dark:bg-slate-800">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold text-slate-900 dark:text-white">
            {isEditing
              ? "تعديل المادة"
              : `إضافة مادة لباقة (${packageData.name})`}
          </h2>
          <button
            onClick={onClose}
            className="rounded-lg p-1 text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700"
          >
            <X size={18} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-6 space-y-4">
          <div>
            <label className="text-sm font-medium text-slate-700 dark:text-slate-200">
              اسم المادة
            </label>
            <input
              value={form.name}
              onChange={updateField("name")}
              className="mt-2 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-200 dark:border-slate-700 dark:bg-slate-900 dark:text-white"
              placeholder="مثال: الجبر والهندسة الفراغية"
            />
          </div>

          <div>
            <label className="text-sm font-medium text-slate-700 dark:text-slate-200">
              الوصف
            </label>
            <textarea
              value={form.description}
              onChange={updateField("description")}
              rows={3}
              className="mt-2 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-200 dark:border-slate-700 dark:bg-slate-900 dark:text-white"
            />
          </div>

          <label className="flex items-center gap-2 text-sm font-medium text-slate-700 dark:text-slate-200">
            <input
              type="checkbox"
              checked={form.is_active}
              onChange={updateField("is_active")}
              className="h-4 w-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
            />
            مادة نشطة
          </label>

          <button
            type="submit"
            disabled={isSaving}
            className="inline-flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 px-6 py-3 text-sm font-semibold text-white shadow-lg transition hover:shadow-xl disabled:opacity-60"
          >
            <Check size={18} />
            {isSaving ? "جارٍ الحفظ..." : "حفظ المادة"}
          </button>
        </form>
      </div>
    </div>
  );
}

// ==========================================
// 4. الصفحة الرئيسية (إدارة الباقات والمواد)
// ==========================================
export default function PackagesManagementPage() {
  const { showToast } = useToast();
  const [packages, setPackages] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  // States for Modals
  const [packageModal, setPackageModal] = useState(null);
  const [subjectModal, setSubjectModal] = useState(null); // { form: initialValues, packageData: parentPackage }

  const loadData = useCallback(async () => {
    setIsLoading(true);
    const supabase = createClient();

    // جلب الباقات مع المواد المرتبطة بها
    const [{ data: packagesData, error: packagesError }, { data: subsData }] =
      await Promise.all([
        supabase
          .from("packages")
          .select("*, subjects(*)")
          .order("created_at", { ascending: false }),
        supabase.from("subscriptions").select("package_id, status"),
      ]);

    if (packagesError) {
      showToast({ type: "error", message: "تعذر تحميل البيانات." });
      setIsLoading(false);
      return;
    }

    const activeCountByPackage = new Map();
    (subsData ?? []).forEach((row) => {
      if (row.status !== "active") return;
      activeCountByPackage.set(
        row.package_id,
        (activeCountByPackage.get(row.package_id) ?? 0) + 1,
      );
    });

    setPackages(
      (packagesData ?? []).map((pkg) => ({
        ...pkg,
        activeStudents: activeCountByPackage.get(pkg.id) ?? 0,
      })),
    );
    setIsLoading(false);
  }, [showToast]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  async function handleDeletePackage(pkg) {
    if (
      !window.confirm(
        `هل أنت متأكد من حذف باقة "${pkg.name}"؟ سيتم حذف جميع المواد بداخلها واشتراكات الطلاب!`,
      )
    )
      return;

    const supabase = createClient();
    const { error } = await supabase.from("packages").delete().eq("id", pkg.id);

    if (error) {
      showToast({ type: "error", message: "تعذر حذف الباقة." });
      return;
    }

    setPackages((prev) => prev.filter((p) => p.id !== pkg.id));
    showToast({ type: "success", message: "تم حذف الباقة بنجاح." });
  }

  async function handleDeleteSubject(subject) {
    if (!window.confirm(`هل أنت متأكد من حذف مادة "${subject.name}"؟`)) return;

    const supabase = createClient();
    const { error } = await supabase
      .from("subjects")
      .delete()
      .eq("id", subject.id);

    if (error) {
      showToast({ type: "error", message: "تعذر حذف المادة." });
      return;
    }
    showToast({ type: "success", message: "تم حذف المادة." });
    loadData(); // إعادة التحميل لتحديث القائمة
  }

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 dark:text-white">
            إدارة الباقات والمواد
          </h1>
          <p className="mt-1 text-slate-600 dark:text-slate-400">
            قم بإنشاء الباقات الدراسية أولاً، ثم أضف المواد بداخلها.
          </p>
        </div>
        <button
          onClick={() => setPackageModal(emptyPackageForm)}
          className="inline-flex items-center gap-2 rounded-lg bg-gradient-to-r from-blue-600 to-indigo-600 px-6 py-2.5 font-medium text-white shadow-lg transition-all hover:shadow-xl hover:scale-105"
        >
          <Plus size={20} />
          إنشاء باقة جديدة
        </button>
      </div>

      {isLoading ? (
        <div className="grid gap-6 grid-cols-1 md:grid-cols-2">
          {Array.from({ length: 2 }).map((_, i) => (
            <Skeleton key={i} className="h-80 w-full rounded-2xl" />
          ))}
        </div>
      ) : packages.length === 0 ? (
        <div className="rounded-xl border border-slate-200 bg-white p-12 text-center shadow-sm dark:border-slate-700 dark:bg-slate-800">
          <BookOpen size={48} className="mx-auto mb-4 text-slate-400" />
          <p className="text-lg font-medium text-slate-900 dark:text-white">
            لا توجد باقات دراسية بعد
          </p>
          <p className="mt-1 text-slate-600 dark:text-slate-400">
            ابدأ بإنشاء الباقة الأولى (مثال: تالتة ثانوي) لتتمكن من إضافة
            المواد.
          </p>
        </div>
      ) : (
        <div className="grid gap-6 grid-cols-1 lg:grid-cols-2">
          {packages.map((pkg) => (
            <div
              key={pkg.id}
              className="flex flex-col overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm dark:border-slate-700 dark:bg-slate-800"
            >
              {/* هيدر الباقة */}
              <div className="border-b border-slate-200 bg-slate-50 p-6 dark:border-slate-700 dark:bg-slate-800/50">
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center gap-3">
                      <h3 className="text-xl font-bold text-slate-900 dark:text-white">
                        {pkg.name}
                      </h3>
                      <span
                        className={`rounded-full px-2.5 py-0.5 text-xs font-semibold ${pkg.is_active ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400" : "bg-slate-200 text-slate-600 dark:bg-slate-700 dark:text-slate-300"}`}
                      >
                        {pkg.is_active ? "نشطة" : "مخفية"}
                      </span>
                    </div>
                    <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
                      {GRADE_LABELS[pkg.grade_level] ?? pkg.grade_level} •{" "}
                      {pkg.price_egp} ج.م
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => setPackageModal(pkg)}
                      className="p-2 text-slate-500 hover:text-blue-600 dark:text-slate-400 dark:hover:text-blue-400"
                    >
                      <Edit size={18} />
                    </button>
                    <button
                      onClick={() => handleDeletePackage(pkg)}
                      className="p-2 text-slate-500 hover:text-red-600 dark:text-slate-400 dark:hover:text-red-400"
                    >
                      <Trash2 size={18} />
                    </button>
                  </div>
                </div>
                <div className="mt-4 flex items-center gap-2 text-sm text-slate-600 dark:text-slate-400">
                  <Users size={16} />
                  <span>{pkg.activeStudents} طالب مشترك بالباقة</span>
                </div>
              </div>

              {/* قسم المواد داخل الباقة */}
              <div className="flex-1 p-6">
                <div className="mb-4 flex items-center justify-between">
                  <h4 className="font-semibold text-slate-900 dark:text-white">
                    المواد الدراسية ({pkg.subjects?.length || 0})
                  </h4>
                  <button
                    onClick={() =>
                      setSubjectModal({
                        form: emptySubjectForm,
                        packageData: pkg,
                      })
                    }
                    className="text-sm font-medium text-blue-600 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300"
                  >
                    + إضافة مادة
                  </button>
                </div>

                {pkg.subjects?.length === 0 ? (
                  <div className="rounded-lg border border-dashed border-slate-300 p-4 text-center text-sm text-slate-500 dark:border-slate-600 dark:text-slate-400">
                    لم يتم إضافة أي مواد لهذه الباقة حتى الآن.
                  </div>
                ) : (
                  <ul className="space-y-3">
                    {pkg.subjects.map((subject) => (
                      <li
                        key={subject.id}
                        className="flex items-center justify-between rounded-lg border border-slate-100 bg-slate-50 p-3 dark:border-slate-700 dark:bg-slate-900/50"
                      >
                        <div className="flex items-center gap-3">
                          <BookOpen size={18} className="text-slate-400" />
                          <span className="font-medium text-slate-800 dark:text-slate-200">
                            {subject.name}
                          </span>
                          {!subject.is_active && (
                            <span className="text-[10px] rounded bg-slate-200 px-1.5 py-0.5 text-slate-600 dark:bg-slate-700 dark:text-slate-300">
                              مخفية
                            </span>
                          )}
                        </div>
                        <div className="flex gap-2">
                          <button
                            onClick={() =>
                              setSubjectModal({
                                form: subject,
                                packageData: pkg,
                              })
                            }
                            className="p-1.5 text-slate-400 hover:text-blue-600 dark:hover:text-blue-400"
                          >
                            <Edit size={16} />
                          </button>
                          <button
                            onClick={() => handleDeleteSubject(subject)}
                            className="p-1.5 text-slate-400 hover:text-red-600 dark:hover:text-red-400"
                          >
                            <Trash2 size={16} />
                          </button>
                        </div>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* نوافذ الـ Modals */}
      {packageModal && (
        <PackageFormModal
          initialValues={packageModal}
          onClose={() => setPackageModal(null)}
          onSaved={() => {
            setPackageModal(null);
            loadData();
          }}
        />
      )}

      {subjectModal && (
        <SubjectFormModal
          initialValues={subjectModal.form}
          packageData={subjectModal.packageData}
          onClose={() => setSubjectModal(null)}
          onSaved={() => {
            setSubjectModal(null);
            loadData();
          }}
        />
      )}
    </div>
  );
}
